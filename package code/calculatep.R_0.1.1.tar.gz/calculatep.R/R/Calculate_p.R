library(CpGassoc)
library(psych)
Calculate_p = function(X,input_phenotype,input,n = 400,nn =4){
  gene_new = X
  df <- input
  df1 = data.matrix(df)
  df2 = t(df1)
  #df2 = read.csv("ESPCA_CONPARE.csv")
  S1 = abs(df2[,1])
  S2 = order(S1,decreasing=TRUE)[1:n]
  data1 <- gene_new[c(S2),1:ncol(gene_new)]
  A = principal(data1)
  PC = A[["residual"]]

  S3 = abs(df2[,2])
  S4 = order(S3,decreasing=TRUE)[1:n]
  data2 <- gene_new[c(S4),1:ncol(gene_new)]
  A2 = principal(data2)
  PC2 = A2[["residual"]]

  S5 = abs(df2[,3])
  S6 = order(S5,decreasing=TRUE)[1:n]
  data3 <- gene_new[c(S6),1:ncol(gene_new)]
  A3 = principal(data3)
  PC3 = A3[["residual"]]

  m = 2*ncol(gene_new)
  Co = matrix(0, ncol(gene_new), nn)
  Co = data.frame(Co)
  #gene_new_1 = PC
  pcz = cbind(PC,PC2)
  gene_new_1 = cbind(pcz,PC3)
  c = 0
  d = 0
  c1 = 0
  Co1 = Co
  Co2 = Co
  av = 0
  av1 = 10000
  k = 1
  k1 = 1
  re_av1[k1] = 0
  p1 = 1

  for (j in seq(1,m,nn)) {
    for (i in 1:nn) {
      if(d == 0){
        Co[,i] = gene_new_1[,j]
        j = j+1
      }else{
        Co1[,i] = gene_new_1[,j]
        j = j+1
      }
    }
    if(d ==0){
      d = 1
    }else{
      Co4 = matrix(0, ncol(gene_new), (ncol(Co)+ncol(Co1)))
      #Co = cbind(Co,Co1)
      for (i in 1:(ncol(Co)+ncol(Co1))) {
        if(i<=ncol(Co)){
          Co4[,i] = Co[,i]
        }else{
          Co4[,i] = Co1[,(i-ncol(Co))]
        }
      }
      Co = Co4
      Co = data.frame(Co)

    }

    test1<-cpg.assoc(gene_new,input_phenotype$Class,Co,large.data=FALSE)
    Pi = test1[["results"]][["T.statistic"]]
    c = sum(test1[["results"]][["Holm.sig"]]==TRUE)
    av = sum(test1[["results"]][["Holm.sig"]]==TRUE)
    if(av < av1){
      c1 = c
      av1 = av
      Co2 = Co
      re_av[k] = av
      k = k+1
    }else{
      p = mean(abs(test1[["results"]][["T.statistic"]]))
      if(av == 0){
        if(is.na(p)==FALSE){
          if(p<p1){
            p1 = p
            c1 = c
            av1 = av
            Co2 = Co
            re_av[k] = av
            k = k+1
          }
        }
      }else{
        Co = Co2
      }
    }
  }
  test1<-cpg.assoc(gene_new,input_phenotype$Class,Co2,large.data=FALSE)
  plot(test1)
  return(Co2)
}
